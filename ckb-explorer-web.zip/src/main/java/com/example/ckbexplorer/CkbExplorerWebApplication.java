package com.example.ckbexplorer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CkbExplorerWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(CkbExplorerWebApplication.class, args);
	}

}
