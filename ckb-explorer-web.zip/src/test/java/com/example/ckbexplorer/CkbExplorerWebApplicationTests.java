package com.example.ckbexplorer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CkbExplorerWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
